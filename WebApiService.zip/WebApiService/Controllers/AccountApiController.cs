﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApiService.Models;

namespace WebApiService.Controllers
{
    
    public class AccountApiController : ApiController
    {
        private PeopleDbContext db = new PeopleDbContext();
        // POST: api/AccountApi/Login
        [HttpPost]
        public IHttpActionResult Login([FromBody] Users model)
        {
            if (ModelState.IsValid)
            {
                // Hash the password from the login request
                var hashedPassword = HashPassword(model.Password);

                // Find user in the database where the Username matches and the hashed password matches
                var user = db.Users.FirstOrDefault(u => u.Username == model.Username && u.Password == model.Password);

                if (user != null)
                {
                    // Successful login
                    return Ok(new { message = "Login successful" });
                }
                else
                {
                    // Invalid username or password
                    return Unauthorized(); // Return 401 Unauthorized for invalid credentials
                }
            }

            return BadRequest(ModelState); // Return 400 Bad Request if model validation fails
        }

        // Example hashing function, replace with your actual hashing method
        private string HashPassword(string password)
        {
            // Hash password (this is just an example)
            using (var sha256 = System.Security.Cryptography.SHA256.Create())
            {
                var bytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return string.Concat(bytes.Select(b => b.ToString("x2")));
            }
        }
    }

}