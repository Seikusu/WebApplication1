﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class AccountController : Controller
    {
        private readonly HttpClient _httpClient;

        public AccountController()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("https://localhost:44320/api/"); // Set to your Web API base URL
        }

        // GET: Account/Login
        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }

        // POST: Account/Login (Authenticate User via API)
        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(Users model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Convert the login model to JSON and send it to the Web API
                    var jsonContent = JsonConvert.SerializeObject(model);
                    var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                    // Send POST request to API login endpoint
                    var response = await _httpClient.PostAsync("AccountApi/Login", content);

                    if (response.IsSuccessStatusCode)
                    {
                        // Optional: Handle token or success response if required
                        // For example, you can extract a JWT token and store it
                        return RedirectToAction("Index", "People"); // Redirect to a secured page on success
                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid username or password.");
                    }
                }
                catch (HttpRequestException ex)
                {
                    ModelState.AddModelError("", "Error communicating with the API: " + ex.Message);
                }
            }
            return View(model);
        }


        // GET: Account/Logout (Handle Logout via API or Client-Side)
        public ActionResult Logout()
        {
            // Here you can call an API to invalidate tokens or just log the user out locally
            // Example: Calling a Web API endpoint for logging out could be added here
            // FormsAuthentication.SignOut(); // If using FormsAuthentication
            return RedirectToAction("Login");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _httpClient.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
